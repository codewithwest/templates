import { MongoClient } from "mongodb";
import * as dotenv from 'dotenv';
dotenv.config();

const live_url = process.env.MONGO_DB_LIVE_URL
const local_url = process.env.MONGO_DB_LOCAL_URL

class db_connection {
    constructor(db_url, db_target, db_collection) {
        this.db_url = db_url
        this.db_target = db_target
        this.db_collection = db_collection
    }
    async listDatabases() {
        console.log(this.db_url)
        let client = new MongoClient(this.db_url)
        await client.connect()
        let databasesList = await client.db().admin().listDatabases()
        console.log("Databases:")
        databasesList.databases.forEach(db => console.log(` - ${db.name}`));
    }
    async getCollections() {
        let client = new MongoClient(this.db_url)

        let collections = await client.db(this.db_target)
            .listCollections()
            .toArray()
        return collections
    }
    async getCollection() {
        let client = new MongoClient(this.db_url)
        var myDb = client.db(this.db_target)
        let myCollection = myDb.collection(this.db_collection)
        return myCollection
    }
    async listCollectionValues() {
        let client = new MongoClient(this.db_url)
        var myDb = client.db(this.db_target)
        let myCollection = myDb.collection(String(this.db_collection))
        let cll = await myCollection.find().toArray()
        return cll
    }
    async dropCollection(get_collection_function) {
        // get_collection_function.drop()
    }
    async createCollection(new_collection_name) {
        // dbo.createCollection(${new_collection_name}, function (err, res) {
        //     if (err) throw err;
        //     console.log("Collection created!");
        //     db.close();
        // });
    }
    exit(kill_collection) {
        kill_collection.close()
    }
}

export {
    db_connection,
    live_url,
    local_url,
}






