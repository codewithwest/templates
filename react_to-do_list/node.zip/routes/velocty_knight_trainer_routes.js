import express, { json, urlencoded } from "express";
import { db_connection, live_url, local_url } from "../auth/connection.js";
import bcrypt from "bcryptjs"
import { InsertRegistrationData } from "../const/functions.js";

const velocity_db = "velocity_trainer"
const velocity_collection = "velocity_users"
// Define router route
var velocity_knight_trainer_routes = express.Router()
// Connect to the database
var get_velocity_collection = new db_connection(local_url, velocity_db, velocity_collection)
// get the desired database collection
var target_velocity_collection = await get_velocity_collection.getCollection()
// Base route
velocity_knight_trainer_routes.get('/velocity_knight_trainer', async (req, res) => {
    // let datalist = await get_velocity_collection.listDatabases()
    // let coll = await get_velocity_collection.collection('velocity_users').find().toArray()
    // console.log(coll)
    // console.log(datalist)
    // res.send(get_velocity_collection.listCollectionValues())
    res.send(req.session)
})

velocity_knight_trainer_routes.post('/velocity_knight_trainer/register', async (req, res) => {
    try {
        console.log(req.body)
        const {
            reg_user_name,
            reg_email,
            reg_con_password } = req.body
        // check if user already exists
        const userEmail = await target_velocity_collection.findOne({ email: reg_email })
        const userName = await target_velocity_collection.findOne({ username: reg_user_name })
        if (userEmail && userName) return res.send({ failure: 'Username and email Exists Login Instead' })
        else if (userEmail) return res.send({ failure: 'Email Exists Login Instead' })
        else if (userName) return res.send({ failure: 'Username Exists Login Instead' })
        else {
            const encryptedPassword = await bcrypt.hash(reg_con_password, 15);
            await InsertRegistrationData(target_velocity_collection, reg_email, '', '', reg_user_name, encryptedPassword)
            // console.log(target_velocity_collection.listCollectionValues())
            res.send({ success: 'Account succefully created !! <br> Proceed To Login' })
        }
    }
    catch (error) { console.log(error) }
})

velocity_knight_trainer_routes.get('/velocity_knight_trainer/login', async (req, res) => {
    // try {
    //         const { sign_username, sign_password } = req.body
    //         if (!(sign_username && sign_password)) res.status(400).send("All input is required")
    //         else {
    //             const user = await myCollection.findOne({ username: sign_username });
    //             // console.log(user)res.status(200).json(user)
    //             if (user && (await bcrypt.compare(sign_password, user.password))) {
    //                 // session = req.session
    //                 req.session.userid = sign_username
    //                 req.session.user = user
    //                 req.session.save()
    //                 res.sendStatus(200)
    //             } else {
    //                 return res.sendStatus(400)
    //             }
    //         }
    //     } catch (err) { console.log(err) }
})

velocity_knight_trainer_routes.get('/velocity_knight_trainer/logout', async (req, res) => {
    // req.session.destroy()
    //     res.redirect('/')
})




export { velocity_knight_trainer_routes }